import { useState, useEffect, useCallback } from "react";
import { ethers } from "ethers";
import { Contract } from "@/lib/contract";
import { useToast } from "@/hooks/use-toast";

// Expected chain ID for Sepolia testnet
const EXPECTED_CHAIN_ID = "0xaa36a7"; // Chain ID for Sepolia

export function useWeb3() {
  const [provider, setProvider] = useState<ethers.BrowserProvider | null>(null);
  const [contract, setContract] = useState<Contract | null>(null);
  const [address, setAddress] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);
  const { toast } = useToast();

  const checkNetwork = async (provider: ethers.BrowserProvider) => {
    const network = await provider.getNetwork();
    return network.chainId.toString(16) === EXPECTED_CHAIN_ID.slice(2); // Remove '0x' prefix for comparison
  };

  const switchNetwork = async () => {
    if (!window.ethereum) return false;

    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: EXPECTED_CHAIN_ID }],
      });
      return true;
    } catch (error: any) {
      if (error.code === 4902) {
        try {
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [{
              chainId: EXPECTED_CHAIN_ID,
              chainName: 'Sepolia Test Network',
              nativeCurrency: {
                name: 'SepoliaETH',
                symbol: 'SEP',
                decimals: 18
              },
              rpcUrls: ['https://rpc.sepolia.org'],
              blockExplorerUrls: ['https://sepolia.etherscan.io']
            }]
          });
          return true;
        } catch (addError) {
          console.error("Failed to add Sepolia network:", addError);
          return false;
        }
      }
      console.error("Failed to switch network:", error);
      return false;
    }
  };

  const connect = useCallback(async () => {
    if (!window.ethereum) {
      toast({
        title: "MetaMask not found",
        description: "Please install MetaMask to use this application",
        variant: "destructive"
      });
      return;
    }

    try {
      setConnecting(true);

      // Request account access
      await window.ethereum.request({ 
        method: 'eth_requestAccounts',
        params: []
      });

      const provider = new ethers.BrowserProvider(window.ethereum);

      // Check if we're on the correct network
      const isCorrectNetwork = await checkNetwork(provider);
      if (!isCorrectNetwork) {
        toast({
          title: "Wrong network",
          description: "Switching to Sepolia network...",
        });

        const switched = await switchNetwork();
        if (!switched) {
          toast({
            title: "Network switch failed",
            description: "Please manually switch to Sepolia network in MetaMask",
            variant: "destructive"
          });
          return;
        }
      }

      const signer = await provider.getSigner();
      const address = await signer.getAddress();

      setProvider(provider);
      setContract(new Contract(provider, signer));
      setAddress(address);

      toast({
        title: "Connected",
        description: "Successfully connected to Sepolia network"
      });
    } catch (error: any) {
      console.error("Failed to connect:", error);
      let description = "Failed to connect to wallet";

      if (error.code === 4001) {
        description = "Connection request rejected. Please try again.";
      } else if (error.code === -32002) {
        description = "Connection request pending. Please check MetaMask.";
      }

      toast({
        title: "Connection failed",
        description,
        variant: "destructive"
      });
    } finally {
      setConnecting(false);
    }
  }, [toast]);

  useEffect(() => {
    // Handle account changes
    if (window.ethereum) {
      window.ethereum.on("accountsChanged", () => {
        window.location.reload();
      });

      window.ethereum.on("chainChanged", () => {
        window.location.reload();
      });
    }
  }, []);

  return {
    provider,
    contract,
    address,
    connecting,
    connect
  };
}