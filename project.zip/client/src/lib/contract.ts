import { ethers } from "ethers";

// Contract ABI with getData and setData functions
const CONTRACT_ABI = [
  {
    "inputs": [
      { "internalType": "int256", "name": "_number", "type": "int256" },
      { "internalType": "string", "name": "_text", "type": "string" }
    ],
    "name": "setData",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getData",
    "outputs": [
      { "internalType": "int256", "name": "", "type": "int256" },
      { "internalType": "string", "name": "", "type": "string" }
    ],
    "stateMutability": "view",
    "type": "function"
  }
];

// Use the environment variable for contract address
const CONTRACT_ADDRESS = import.meta.env.VITE_CONTRACT_ADDRESS;

export class Contract {
  private contract: ethers.Contract;
  private signer: ethers.JsonRpcSigner;

  constructor(provider: ethers.BrowserProvider, signer: ethers.JsonRpcSigner) {
    this.contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);
    this.signer = signer;
  }

  async getValues() {
    const data = await this.contract.getData();
    return {
      intValue: data[0].toString(),
      stringValue: data[1]
    };
  }

  async setValues(number: string, text: string) {
    const contract = this.contract.connect(this.signer);
    const tx = await contract.setData(number, text);
    await tx.wait();
  }
}