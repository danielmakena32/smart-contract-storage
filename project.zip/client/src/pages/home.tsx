import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useWeb3 } from "@/hooks/use-web3";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Wallet2, Copy, CheckCheck } from "lucide-react";

export default function Home() {
  const { contract, address, connecting, connect } = useWeb3();
  const { toast } = useToast();
  const [storedNumber, setStoredNumber] = useState("");
  const [storedText, setStoredText] = useState("");
  const [newNumber, setNewNumber] = useState("");
  const [newText, setNewText] = useState("");
  const [updating, setUpdating] = useState(false);
  const [copied, setCopied] = useState(false);

  const truncateAddress = (addr: string) => {
    return `${addr.substring(0, 6)}...${addr.substring(addr.length - 4)}`;
  };

  const copyAddress = async () => {
    if (address) {
      await navigator.clipboard.writeText(address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: "Address copied",
        description: "Wallet address copied to clipboard"
      });
    }
  };


  // Fetch current values
  useEffect(() => {
    fetchData();
  }, [contract]);

  async function fetchData() {
    if (!contract) return;
    try {
      const values = await contract.getValues();
      setStoredNumber(values.intValue);
      setStoredText(values.stringValue);
    } catch (error) {
      console.error("Failed to fetch data:", error);
      toast({
        title: "Error",
        description: "Failed to fetch current values",
        variant: "destructive"
      });
    }
  }

  async function updateData() {
    if (!contract) return;
    try {
      setUpdating(true);
      await contract.setValues(newNumber, newText);
      await fetchData();
      setNewNumber("");
      setNewText("");
      toast({
        title: "Success",
        description: "Values updated successfully"
      });
    } catch (error) {
      console.error("Failed to update data:", error);
      toast({
        title: "Error",
        description: "Failed to update values",
        variant: "destructive"
      });
    } finally {
      setUpdating(false);
    }
  }

  if (!address) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-blue-50 to-indigo-50 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-center">
              Connect Your Wallet
            </CardTitle>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Button
              size="lg"
              onClick={connect}
              disabled={connecting}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              <Wallet2 className="mr-2 h-5 w-5" />
              {connecting ? "Connecting..." : "Connect MetaMask"}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-r from-blue-50 to-indigo-50 p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-xl flex items-center justify-between">
              <span>Connected Wallet</span>
              <div className="flex items-center gap-2">
                <span className="text-sm font-normal text-gray-600">
                  {truncateAddress(address)}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={copyAddress}
                  className="h-8 w-8"
                >
                  {copied ? (
                    <CheckCheck className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Current Values</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <p className="font-semibold mb-2">Stored Number:</p>
                <p className="text-lg">{storedNumber}</p>
              </div>
              <div>
                <p className="font-semibold mb-2">Stored Text:</p>
                <p className="text-lg">{storedText}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Update Values</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">New Number</label>
                <Input
                  type="number"
                  placeholder="Enter new number"
                  value={newNumber}
                  onChange={(e) => setNewNumber(e.target.value)}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">New Text</label>
                <Input
                  type="text"
                  placeholder="Enter new text"
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                  className="w-full"
                />
              </div>
              <Button
                onClick={updateData}
                disabled={updating}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
              >
                {updating ? "Updating..." : "Update Values"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}