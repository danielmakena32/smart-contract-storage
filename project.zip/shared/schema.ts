import { z } from "zod";

// Schema for contract values
export const contractValuesSchema = z.object({
  intValue: z.string(),
  stringValue: z.string()
});

export type ContractValues = z.infer<typeof contractValuesSchema>;

// Schema for updating contract values
export const updateIntValueSchema = z.object({
  value: z.string().refine((val) => {
    try {
      // Check if value can be parsed as BigInt
      BigInt(val);
      return true;
    } catch {
      return false;
    }
  }, "Must be a valid integer value")
});

export const updateStringValueSchema = z.object({
  value: z.string().min(1, "String value cannot be empty")
});

export type UpdateIntValue = z.infer<typeof updateIntValueSchema>;
export type UpdateStringValue = z.infer<typeof updateStringValueSchema>;
